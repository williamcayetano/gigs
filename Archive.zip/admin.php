<?php
  include_once("scripts/connectToMySQL.php");
  include_once("scripts/checkuserlog.php");
  include_once("scripts/includeFunctions.php");
  
  $msg = '';
  $catArray = array();
  $subArray = array();
  $catTable = '';
  $selectedCat = '--';
  
  if (isset($_SESSION['idx'])) {
    $id = $logOptions_id;
    //if not master account, restricted area
    if ($id != 1) {
      header("location: index.php");
    }
  } else {
    header("location: index.php");
  }
  
   $todaysDateTime = time();
   $morning = mktime(0, 0, 0, date("m"), date("d"), date("y"));
   $midnight = mktime(0, 0, 0, date("m"), date("d")+1, date("y"));
   $sqlMorning = date("Y-m-d H:i:s", $morning);
   $sqlMidnight = date("Y-m-d H:i:s", $midnight);
   
   $ipAddress = getenv('REMOTE_ADDR');
   $sqlTotalIP = mysqli_query($link, "SELECT * FROM logs");
   $totalIPCount = mysqli_num_rows($sqlTotalIP);
   $sqlTotalIPMinus = mysqli_query($link, "SELECT * FROM logs WHERE ipaddress NOT LIKE '$ipAddress'");
   $totalMinusCount = mysqli_num_rows($sqlTotalIPMinus);
   $sqlTotalDistinct = mysqli_query($link, "SELECT DISTINCT ipaddress FROM logs");
   $totalDistinctCount = mysqli_num_rows($sqlTotalDistinct);
    
   $sqlTotalDay = mysqli_query($link, "SELECT * FROM logs WHERE post_date BETWEEN '$sqlMorning' AND '$sqlMidnight'");
   $totalDay = mysqli_num_rows($sqlTotalDay);
   $sqlDistinctDay = mysqli_query($link, "SELECT DISTINCT ipaddress FROM logs WHERE post_date BETWEEN '$sqlMorning' AND '$sqlMidnight'");
   $totalDistinctDay = mysqli_num_rows($sqlDistinctDay);
    
   $formatPostTime = date("m/d/y"); 
    
   $logTable = '<table class="log_table" border="1" cellpadding="5">
     			  <tr> 
     			    <th>
     			      Date
     			    </th>
     			    <th>
     			      Total Hits
     			    </th>
     			    <th>
     			      Total Hits Minus
     			    </th>
     			    <th>
     			      Total Distinct
     			    </th>
     			    <th>
     			      Total Today
     			    </th>
     			    <th>
     			      Total Distinct Today
     			    </th>
     			  </tr>
     			  <tr>
     			    <td class="column_data">
     			      ' . $formatPostTime . '
     			    </td>
     			    <td class="column_data">
     			      ' . $totalIPCount . '
     			    </td>
     			    <td class="column_data">
     			      ' . $totalMinusCount . '
     			    </td>
     			    <td class="column_data">
     			      ' . $totalDistinctCount . '
     			    </td>
     			    <td class="column_data">
     			      ' . $totalDay . '
     			    </td>
     			    <td class="column_data">
     			      ' . $totalDistinctDay . '
     			    </td>
     			  </tr>
    			</table>';
    			 
  $sqlGetCat = mysqli_query($link, "SELECT * FROM categories");
  $sqlNumCat = mysqli_num_rows($sqlGetCat);
  
  if ($sqlNumCat > 0) {
    while ($row = mysqli_fetch_array($sqlGetCat)) {
      $catID = $row['id'];
      $category = $row['category_name'];
      $subCategory = $row['subcategory_name'];
      $weight = $row['weight'];
      $active = $row['active'];
      
      $subCategory != '' ? $subArray[] = $weight . '`' . $category . '`' . $subCategory . '`' . $catID . '`' . $active : '';
      $catArray[$category] = $subArray;
      //$catArray[] = $category . '`' . $subCategory; 
    }
  }
  //var_dump($catArray);
  
  /*foreach ($catArray as $key => $value) {
    $catTable .= '<table class="cat_table" border="1" cellpadding="5">
                   <tr>
                     <th>
                       ' . $key . '
                     </th>
                   </tr>
                   <tr>
                     ' . foreach ($catArray[$key] as $key2 => $value2)  . '
                     <td class="cat">
                       ' . $key2 . '
                     </td>
                     ' . endforeach . '
                   <tr>
    			</table>';
  }*/
  
  if (isset($_POST['button']) && $id == 1) {
    $catDrop = strtolower($_POST['catSelect']);
    $newCat = strtolower($_POST['newCat']);
    $newSub = strtolower($_POST['newSub']);
    
    //i want to make sure you're either adding a subcategory to an existing
    //category or starting a new category alltogether
    if ($catDrop != '--' && $newSub != '' && $newCat == '') {
      $catDrop = clean($catDrop);
      $newSub = clean($newSub);
      
      $sqlSelectCat = mysqli_query($link, "SELECT * FROM categories WHERE category_name='$catDrop' AND subcategory_name='$newSub'");
      $sqlCatCount = mysqli_num_rows($sqlSelectCat);
      
      if ($sqlCatCount > 0) {
        $msg = "$newSub is already added to $catDrop";
      } else {
        $sqlInsertCat = mysqli_query($link, "INSERT INTO categories (category_name, subcategory_name) VALUES ('$catDrop', '$newSub')");
        $msg = "$newSub has been added to $catDrop";
      }
    } else if ($newCat != '' && $catDrop == '--') {
      $newCat = clean($newCat);
      $newSub = clean($newSub);
      
      if ($newSub != '') {
        $sqlSelectCat = mysqli_query($link, "SELECT * FROM categories WHERE category_name='$newCat' AND subcategory_name='$newSub'");
        $sqlCatCount = mysqli_num_rows($sqlSelectCat);
         
        if ($sqlCatCount > 0) {
          $msg = "$newCat and $newSub already exists";
        } else {
          $sqlInsertCat = mysqli_query($link, "INSERT INTO categories (category_name, subcategory_name) VALUES ('$newCat', '$newSub')");
          $msg = "$newCat has been created with $newSub";
        }
      } else {
        $sqlSelectCat = mysqli_query($link, "SELECT * FROM categories WHERE category_name='$newCat'");
        $sqlCatCount = mysqli_num_rows($sqlSelectCat);
        
        if ($sqlCatCount > 0) {
          $msg = "$newCat already exists";
        } else {
          $sqlInsertCat = mysqli_query($link, "INSERT INTO categories (category_name) VALUES ('$newCat')");
          $msg = "$newCat has been created";
        }
      }
    } else {
      $msg = "There's been a gross miscalculation";
    }
  
  } else if (isset($_POST['button2'])  && $id == 1) {
    $catID = preg_replace('#[^0-9]#', '', $_POST['id']);
    $subCat = clean($_POST['subCat']);
    $weight = preg_replace('#[^0-9]#', '', $_POST['weight']);
    $active = preg_replace('#[^yn]#', '', $_POST['active']);
    
    if (strcmp($active,'n') != 0 && strcmp($active,'y') != 0) {//I had || here, but this kept giving false positives
      $msg = 'Active can only be y or n';
    } else if (!is_numeric($weight) || count($weight) > 2) {
      $msg = 'Weight has to be numeric and no more han two digits';
    } else {
      $sqlUpdateCat = mysqli_query($link, "UPDATE categories SET subcategory_name='$subCat', weight='$weight', active='$active' WHERE id='$catID'");
      $msg = 'Sub-Category updated';
    }
  }
?>

<html>
<head>
  <style>
  .column_data {
    text-align: center;
  }
  </style>
</head>
<body>
  <a href="index.php">Home</a>
  <h3><?php echo $msg; ?></h3>
  <?php echo isset($logTable) ? $logTable : ''; ?>
  <br />
  <form action="admin.php" method="post" name="categoryForm" id="categoryForm">
    Category:<select name="catSelect"><?php print dropDown(array_keys($catArray), $selectedCat); ?></select><br />
    Add New Category: <input type="text" name="newCat" id="newCat" size="20" /><br />
    Add New SubCategory: <input type="text" name="newSub" id="newSub" size="20" /><span class="grey_color">Select or Type Category First</span><br />
    <input type="submit" name="button" id="button" value="Submit"/>
  </form>
    
  
    <table class="master">
      <tr>
        <td class="master_row">
    	<?php 
    	  for ($index = 0; $index < count($catArray); $index++) :
      		foreach ($catArray as $key => $value) : 
      	?>
      		  <table class="cat_table" border="1" cellpadding="5">
        		<tr>
          		  <th colspan="4">
            	    <?php echo $key; ?>
          		  </th>
          		</tr>
        		<tr>
          		  <th>
            		ID
          		  </th>
          		  <th>
            		Sub-Category
          		  </th>
          		  <th>
            		Weight
          		  </th>
          		  <th>
            		Active
          		  </th>
        		</tr>
         		<?php 
               	  foreach ($catArray[$key] as $key2 => $value2) : 
                 	$kaboom = explode("`", $value2);
                 	$stringWeight = $kaboom[0];
                 	$stringCat = $kaboom[1];
                 	$stringSub = $kaboom[2];
                 	$stringID = $kaboom[3];
                 	$stringActive = $kaboom[4];
                 
                 	if ($key == $stringCat) : 
                ?>
          		<tr> 
          		  <form action="admin.php" method="post" name="subCategoryForm" id="subCategoryForm">
            	  <td class="id">
              		<?php echo $stringID; ?>
            	  </td>
            	  <td class="sub">
              		<input type="text" name="subCat" id="subCat" size="12" value="<?php echo $stringSub; ?>" />
            	  </td>
            	  <td class="weight">
              		<input type="text" name="weight" id="weight" size="2" value="<?php echo $stringWeight; ?>" />
            	  </td>
            	  <td class="active">
              		<input type="text" name="active" id="name" size="1" value="<?php echo $stringActive; ?>" />
            	  </td>
            	  <td class="submit">
            	    <input type="hidden" name="id" value="<?php echo $stringID; ?>" />
                    <input type="submit" name="button2" id="button2" value="Submit"/>
            	  </td>
            	  </form>
          		</tr>
         		<?php
           		  	endif;
         		  endforeach; 
         		?>
       		  </table>
     	<?php 
     	    echo '</td><td class="master_row">';
     	    $index++;
            if ($index % 3 == 0) { 
              echo '</tr><tr><td class="master_row">';
            }
            endforeach;
          endfor; 
          echo '</td></tr></table><br />';
        ?>
</body>
</html>