<?php
  $link = mysqli_connect("localhost", "root", "root", "odd_jobr") or die (mysqli_error());
?>